--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.2
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE aikamtest;
--
-- Name: aikamtest; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE aikamtest WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Russian_Russia.1251' LC_CTYPE = 'Russian_Russia.1251';


ALTER DATABASE aikamtest OWNER TO postgres;

\connect aikamtest

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: average_expenses(date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.average_expenses(start date, finish date) RETURNS TABLE(average_expenses numeric)
    LANGUAGE plpgsql
    AS $$BEGIN
	RETURN QUERY
	SELECT CAST(AVG(sum) AS NUMERIC(9,2)) FROM (
		SELECT SUM(price) sum
		FROM purchase 
		JOIN customer ON purchase.customer_id = customer.customer_id
		JOIN product ON purchase.product_id = product.product_id
		WHERE date BETWEEN start AND finish
		GROUP BY customer.customer_id
	) total_expences_by_customer;
END;  $$;


ALTER FUNCTION public.average_expenses(start date, finish date) OWNER TO postgres;

--
-- Name: customers_bad_search(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.customers_bad_search(lmt integer) RETURNS TABLE(first_name character varying, last_name character varying)
    LANGUAGE plpgsql
    AS $$BEGIN
	RETURN QUERY
	SELECT customer.last_name, customer.first_name
	FROM purchase 
	JOIN customer ON purchase.customer_id = customer.customer_id
	JOIN product ON purchase.product_id = product.product_id
	GROUP BY customer.customer_id
	ORDER BY COUNT(purchase.purchase_id) ASC
	LIMIT lmt;
END; $$;


ALTER FUNCTION public.customers_bad_search(lmt integer) OWNER TO postgres;

--
-- Name: customers_interval_search(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.customers_interval_search(min integer, max integer) RETURNS TABLE(first_name character varying, last_name character varying)
    LANGUAGE plpgsql
    AS $$BEGIN
	RETURN QUERY
	SELECT customer.last_name, customer.first_name
	FROM purchase 
	JOIN customer ON purchase.customer_id = customer.customer_id
	JOIN product ON purchase.product_id = product.product_id
	GROUP BY customer.customer_id
	HAVING SUM(product.price) BETWEEN min AND max;
END; $$;


ALTER FUNCTION public.customers_interval_search(min integer, max integer) OWNER TO postgres;

--
-- Name: customers_last_name_search(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.customers_last_name_search(lname character varying) RETURNS TABLE(first_name character varying, last_name character varying)
    LANGUAGE plpgsql
    AS $$BEGIN
	RETURN QUERY 
	SELECT customer.last_name, customer.first_name FROM customer
	WHERE customer.last_name = lname;
END; $$;


ALTER FUNCTION public.customers_last_name_search(lname character varying) OWNER TO postgres;

--
-- Name: customers_product_search(character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.customers_product_search(pname character varying, cnt integer) RETURNS TABLE(first_name character varying, last_name character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
	RETURN QUERY 
	SELECT customer.last_name, customer.first_name
	FROM purchase 
	JOIN customer ON purchase.customer_id = customer.customer_id
	JOIN product ON purchase.product_id = product.product_id
	WHERE product.name = pname
	GROUP BY customer.customer_id
	HAVING COUNT(purchase_id) >= cnt;
END; $$;


ALTER FUNCTION public.customers_product_search(pname character varying, cnt integer) OWNER TO postgres;

--
-- Name: customers_product_stat(date, date, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.customers_product_stat(start date, finish date, c_id integer) RETURNS TABLE(product_name character varying, sum_expense bigint)
    LANGUAGE plpgsql
    AS $$
BEGIN
   RETURN QUERY
	SELECT product.name AS product_name, SUM(price) AS sum_expense 
	FROM purchase 
	JOIN customer ON purchase.customer_id = customer.customer_id
	JOIN product ON purchase.product_id = product.product_id
	WHERE date BETWEEN start AND finish
	AND customer.customer_id = c_id
	GROUP BY customer.customer_id, product.product_id;
END; $$;


ALTER FUNCTION public.customers_product_stat(start date, finish date, c_id integer) OWNER TO postgres;

--
-- Name: get_customers(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_customers() RETURNS TABLE(customer_id integer, last_name character varying, first_name character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
   RETURN QUERY 
   SELECT customer.customer_id, customer.last_name, customer.first_name
   FROM customer;
END;  $$;


ALTER FUNCTION public.get_customers() OWNER TO postgres;

--
-- Name: total_expenses(date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.total_expenses(start date, finish date) RETURNS TABLE(total_expenses bigint)
    LANGUAGE plpgsql
    AS $$
BEGIN
	RETURN QUERY
	SELECT SUM(price) AS total_expenses
	FROM purchase
	JOIN product ON purchase.product_id = product.product_id
	WHERE date BETWEEN start AND finish;
END;  $$;


ALTER FUNCTION public.total_expenses(start date, finish date) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    customer_id integer NOT NULL,
    last_name character varying(50) NOT NULL,
    first_name character varying(50) NOT NULL
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customers_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customers_customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customers_customer_id_seq OWNER TO postgres;

--
-- Name: customers_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customers_customer_id_seq OWNED BY public.customer.customer_id;


--
-- Name: product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product (
    product_id integer NOT NULL,
    name character varying(50) NOT NULL,
    price integer NOT NULL
);


ALTER TABLE public.product OWNER TO postgres;

--
-- Name: product_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_product_id_seq OWNER TO postgres;

--
-- Name: product_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_product_id_seq OWNED BY public.product.product_id;


--
-- Name: purchase; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase (
    purchase_id integer NOT NULL,
    customer_id integer NOT NULL,
    product_id integer NOT NULL,
    date date NOT NULL
);


ALTER TABLE public.purchase OWNER TO postgres;

--
-- Name: purchase_purchase_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.purchase_purchase_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_purchase_id_seq OWNER TO postgres;

--
-- Name: purchase_purchase_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.purchase_purchase_id_seq OWNED BY public.purchase.purchase_id;


--
-- Name: customer customer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer ALTER COLUMN customer_id SET DEFAULT nextval('public.customers_customer_id_seq'::regclass);


--
-- Name: product product_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product ALTER COLUMN product_id SET DEFAULT nextval('public.product_product_id_seq'::regclass);


--
-- Name: purchase purchase_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase ALTER COLUMN purchase_id SET DEFAULT nextval('public.purchase_purchase_id_seq'::regclass);


--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (customer_id, last_name, first_name) FROM stdin;
\.
COPY public.customer (customer_id, last_name, first_name) FROM '$$PATH$$/2845.dat';

--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product (product_id, name, price) FROM stdin;
\.
COPY public.product (product_id, name, price) FROM '$$PATH$$/2847.dat';

--
-- Data for Name: purchase; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase (purchase_id, customer_id, product_id, date) FROM stdin;
\.
COPY public.purchase (purchase_id, customer_id, product_id, date) FROM '$$PATH$$/2849.dat';

--
-- Name: customers_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_customer_id_seq', 10, true);


--
-- Name: product_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_product_id_seq', 9, true);


--
-- Name: purchase_purchase_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.purchase_purchase_id_seq', 94, true);


--
-- Name: customer customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customers_pkey PRIMARY KEY (customer_id);


--
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (product_id);


--
-- Name: purchase purchase_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase
    ADD CONSTRAINT purchase_pkey PRIMARY KEY (purchase_id);


--
-- Name: purchase purchase_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase
    ADD CONSTRAINT purchase_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- Name: purchase purchase_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase
    ADD CONSTRAINT purchase_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(product_id);


--
-- PostgreSQL database dump complete
--

